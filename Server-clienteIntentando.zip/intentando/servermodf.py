# -*- coding: utf-8 -*- 
import wx
#importamos el modulo socket
from socket import *
from time import ctime
import random
import threading
# definir el puerto por el cual se recibiran las peticiones
port=8080
#Definimos el host,Es mejor dejarlo en blanco para recibir conexiones externas si es nuestro caso
host = ''
#definimos una tupla con los datos del host y el puerto
addr = (host, port)
#definimos en la variable  la cantidad de bytes para recibir desde un cliente
bufsiz = 1024
###########################################################################
## Python code generated with wxFormBuilder (version Jun 17 2015)
## http://www.wxformbuilder.org/
##
## PLEASE DO "NOT" EDIT THIS FILE!
###########################################################################

#import wx
import wx.xrc

###########################################################################
## Class FrmServer
###########################################################################

class FrmServer ( wx.Frame ):
	
	def __init__( self, parent ):
		wx.Frame.__init__ ( self, parent, id = wx.ID_ANY, title = wx.EmptyString, pos = wx.DefaultPosition, size = wx.Size( 885,600 ), style = wx.DEFAULT_FRAME_STYLE|wx.TAB_TRAVERSAL )
		
		self.SetSizeHintsSz( wx.DefaultSize, wx.DefaultSize )
		self.SetBackgroundColour( wx.SystemSettings.GetColour( wx.SYS_COLOUR_INACTIVECAPTIONTEXT ) )
		
		fgSizer3 = wx.FlexGridSizer( 0, 2, 0, 0 )
		fgSizer3.SetFlexibleDirection( wx.BOTH )
		fgSizer3.SetNonFlexibleGrowMode( wx.FLEX_GROWMODE_SPECIFIED )
		
		self.m_staticText1 = wx.StaticText( self, wx.ID_ANY, u"Enviar mensajes con Sockets a traves de Python", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText1.Wrap( -1 )
		fgSizer3.Add( self.m_staticText1, 0, wx.ALL, 5 )
		
		
		fgSizer3.AddSpacer( ( 0, 0), 1, wx.EXPAND, 5 )
		
		fgSizer4 = wx.FlexGridSizer( 0, 5, 0, 0 )
		fgSizer4.SetFlexibleDirection( wx.BOTH )
		fgSizer4.SetNonFlexibleGrowMode( wx.FLEX_GROWMODE_SPECIFIED )
		
		self.lblIPSERVER = wx.StaticText( self, wx.ID_ANY, u"IP Server:", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.lblIPSERVER.Wrap( -1 )
		self.lblIPSERVER.SetForegroundColour( wx.SystemSettings.GetColour( wx.SYS_COLOUR_HIGHLIGHT ) )
		
		fgSizer4.Add( self.lblIPSERVER, 0, wx.ALL, 5 )
		
		self.txtServer = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.Size( 250,30 ), 0 )
		fgSizer4.Add( self.txtServer, 0, wx.ALL, 5 )
		
		self.lblPuerto = wx.StaticText( self, wx.ID_ANY, u"Puerto:", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.lblPuerto.Wrap( -1 )
		self.lblPuerto.SetForegroundColour( wx.SystemSettings.GetColour( wx.SYS_COLOUR_HIGHLIGHT ) )
		
		fgSizer4.Add( self.lblPuerto, 0, wx.ALL, 5 )
		
		self.txtPuerto = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.Size( 200,30 ), 0 )
		fgSizer4.Add( self.txtPuerto, 0, wx.ALL, 5 )
		
		self.btnConectar = wx.Button( self, wx.ID_ANY, u"Conectar", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.btnConectar.SetForegroundColour( wx.SystemSettings.GetColour( wx.SYS_COLOUR_HIGHLIGHTTEXT ) )
		self.btnConectar.SetBackgroundColour( wx.SystemSettings.GetColour( wx.SYS_COLOUR_HIGHLIGHT ) )
		
		fgSizer4.Add( self.btnConectar, 0, wx.ALL, 5 )
		
		self.lblMensaje = wx.StaticText( self, wx.ID_ANY, u"Mensaje:", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.lblMensaje.Wrap( -1 )
		self.lblMensaje.SetForegroundColour( wx.SystemSettings.GetColour( wx.SYS_COLOUR_HIGHLIGHT ) )
		
		fgSizer4.Add( self.lblMensaje, 0, wx.ALL, 5 )
		
		self.txtMensaje = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.Size( 300,30 ), 0 )
		fgSizer4.Add( self.txtMensaje, 0, wx.ALL, 5 )
		
		self.btnEnviar = wx.Button( self, wx.ID_ANY, u"Enviar", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.btnEnviar.SetForegroundColour( wx.SystemSettings.GetColour( wx.SYS_COLOUR_HIGHLIGHTTEXT ) )
		self.btnEnviar.SetBackgroundColour( wx.SystemSettings.GetColour( wx.SYS_COLOUR_HIGHLIGHT ) )
		
		fgSizer4.Add( self.btnEnviar, 0, wx.ALL, 5 )
		
		
		fgSizer4.AddSpacer( ( 0, 0), 1, wx.EXPAND, 5 )
		
		
		fgSizer4.AddSpacer( ( 0, 0), 1, wx.EXPAND, 5 )
		
		
		fgSizer4.AddSpacer( ( 0, 0), 1, wx.EXPAND, 5 )
		
		self.txtChat = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.Size( 250,300 ), 0 )
		fgSizer4.Add( self.txtChat, 0, wx.ALL, 5 )
		
		
		fgSizer3.Add( fgSizer4, 1, wx.EXPAND, 5 )
		
		
		self.SetSizer( fgSizer3 )
		self.Layout()
		
		self.Centre( wx.BOTH )
		def Print(self, text):
			wx.CallAfter(self.text.AppendText, text +"/n")
		def Server(self):
			self.Print("Puerto: {}".format(port))
		#instanciamos un objeto para trabajar con el socket
        self.tcpServer = socket(AF_INET , SOCK_STREAM)
        #Con el metodo bind le indicamos que puerto debe escuchar y de que servidor esperar conexiones
        # addr es una tupla que definimos anteriormente con el host y puerto
        self.tcpServer.bind(addr)
        #Aceptamos conexiones entrantes con el metodo listen, y ademas aplicamos como parametro
		#El numero de conexiones entrantes que vamos a aceptar
        self.tcpServer.listen(5)
        try:
            while True:
                self.Print("Esperando la conexion...")
                #Instanciamos un objeto sc (socket cliente) para recibir datos, al recibir datos este 
				#devolvera tambien un objeto que representa una tupla con los datos de conexion: IP y puerto
                tcpClient, caddr = self.tcpServer.accept()
                self.Print("Conectado desde {}".format(caddr))

                while True:
					#Recibimos el mensaje, con el metodo recv recibimos datos 
					# y como parametro  la cantidad de bytes para recibir 
                    data = tcpClient.recv(bufsiz)
                    if not data:
                        break
                    tcpClient.send('[%s]\nData\n%s' % (ctime(), data))
                    self.Print(data)
                tcpClient.close()

        except KeyboardInterrupt:
            tcpServer.close()

	def __del__(self):
		self.tcpServer.close()
		self.Close()
app = wx.App(False)
win = MainWindow(None)
app.MainLoop()
			
	
