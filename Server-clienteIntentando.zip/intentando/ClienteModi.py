# -*- coding: utf-8 -*- 
import socket
###########################################################################
## Python code generated with wxFormBuilder (version Jun 17 2015)
## http://www.wxformbuilder.org/
##
## PLEASE DO "NOT" EDIT THIS FILE!
###########################################################################

import wx
import wx.xrc


###########################################################################
## Class FrmClient
###########################################################################

class FrmClient ( wx.Frame ):
	
	def __init__( self, parent ):
		wx.Frame.__init__ ( self, parent, id = wx.ID_ANY, title = wx.EmptyString, pos = wx.DefaultPosition, size = wx.Size( 466,300 ), style = wx.DEFAULT_FRAME_STYLE|wx.TAB_TRAVERSAL )
		
		self.SetSizeHintsSz( wx.DefaultSize, wx.DefaultSize )
		self.SetForegroundColour( wx.SystemSettings.GetColour( wx.SYS_COLOUR_HIGHLIGHTTEXT ) )
		self.SetBackgroundColour( wx.SystemSettings.GetColour( wx.SYS_COLOUR_WINDOWTEXT ) )
		
		fgSizer1 = wx.FlexGridSizer( 3, 1, 0, 0 )
		fgSizer1.SetFlexibleDirection( wx.BOTH )
		fgSizer1.SetNonFlexibleGrowMode( wx.FLEX_GROWMODE_SPECIFIED )
		
		self.txtEnviar = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.Size( 350,30 ), 0 )
		self.txtEnviar.SetForegroundColour( wx.SystemSettings.GetColour( wx.SYS_COLOUR_HIGHLIGHTTEXT ) )
		self.txtEnviar.SetBackgroundColour( wx.SystemSettings.GetColour( wx.SYS_COLOUR_HIGHLIGHT ) )
		
		fgSizer1.Add( self.txtEnviar, 0, wx.ALL, 5 )
		
		self.btnEnviar = wx.Button( self, wx.ID_ANY, u"Enviar", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.btnEnviar.SetForegroundColour( wx.SystemSettings.GetColour( wx.SYS_COLOUR_HIGHLIGHTTEXT ) )
		self.btnEnviar.SetBackgroundColour( wx.SystemSettings.GetColour( wx.SYS_COLOUR_HIGHLIGHT ) )
		
		fgSizer1.Add( self.btnEnviar, 0, wx.ALL, 5 )
		
		
		fgSizer1.AddSpacer( ( 0, 0), 1, wx.EXPAND, 5 )
		
		
		fgSizer1.AddSpacer( ( 0, 0), 1, wx.EXPAND, 5 )
		
		self.m_panel2 = wx.Panel( self, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL )
		fgSizer1.Add( self.m_panel2, 1, wx.EXPAND |wx.ALL, 5 )
		
		
		fgSizer1.AddSpacer( ( 0, 0), 1, wx.EXPAND, 5 )
		
		self.txtChat = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.Point( -1,-1 ), wx.Size( 300,200 ), 0 )
		self.txtChat.SetForegroundColour( wx.SystemSettings.GetColour( wx.SYS_COLOUR_HIGHLIGHTTEXT ) )
		self.txtChat.SetBackgroundColour( wx.SystemSettings.GetColour( wx.SYS_COLOUR_HIGHLIGHT ) )
		
		fgSizer1.Add( self.txtChat, 0, wx.ALL, 5 )
		
		
		self.SetSizer( fgSizer1 )
		self.Layout()
		
		self.Centre( wx.BOTH )
		# Connect Events
		self.btnEnviar.Bind( wx.EVT_BUTTON, self.Enviar )
		self.btnConectar.Bind( wx.EVT_BUTTON, self.Conectar )
		self.port =8080

		self.txt_Puerto.SetValue(str(self.port))
		self.txt_Ip.SetValue('localhost')
	def __del__( self ):
		#pass
		self.client.shutdown(socket.SHUT_RDWR)
		self.client.close()	
	
	# Virtual event handlers, overide them in your derived class
	def Conectar( self, event ):
		self.ip=str(self.txt_Ip.GetValue())
		self.port =int(self.txt_Puerto.GetValue())
		self.client = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
		self.client.connect((self.ip, self.port))		
			
	def Enviar( self, event ):
		self.port =int(self.txt_Puerto.GetValue())
		self.ip=str(self.txt_Ip.GetValue())
		#self.client.close()	
		#self.client.connect((self.ip, self.port))
		#def sendSocketMessage(message):
		"""Send a message to a socket"""
		try:
			#port = random.randint(1025,36000)
			self.message=self.txt_Mensaje.GetValue()			
			if self.message=='salir':
				self.Close()
			else:
				self.client.send(self.message)
			
				self.txt_Mensaje.SetValue("")
		except Exception, msg:
			print msg	
#----------------------------------------------------------------------
# end of class MyFrame
class MyApp(wx.App):
    def OnInit(self):
        FrmClient = txtEnviar(None)
        self.SetTopWindow(frame)
        FrmClient.Show()
        return 1

# end of class MyApp

if __name__ == "__main__":
    app = MyApp(0)
    app.MainLoop()
        
#if __name__ == "__main__":
    #sendSocketMessage("Python rocks!")
    
